package com.example.audio

import android.media.AudioAttributes
import android.media.MediaPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class HybridAudioPlayer(
    private val scope: CoroutineScope,
    private val onPrepared: (durationSeconds: Int) -> Unit,
    private val onCompletion: () -> Unit,
    private val onError: (String) -> Unit
) {
    private val synthEngine = SynthAudioEngine(scope)
    private var mediaPlayer: MediaPlayer? = null
    private var activeUrl: String? = null
    private var isUrlPrepared: Boolean = false

    fun play(audioUrl: String, synthMood: String) {
        val cleanUrl = audioUrl.trim()
        if (cleanUrl.isEmpty()) {
            releaseMediaPlayer()
            activeUrl = null
            isUrlPrepared = false
            synthEngine.start(synthMood)
            onPrepared(-1)
            return
        }

        if (!cleanUrl.startsWith("http://", ignoreCase = true) &&
            !cleanUrl.startsWith("https://", ignoreCase = true) &&
            !cleanUrl.startsWith("content://", ignoreCase = true)
        ) {
            synthEngine.pause()
            releaseMediaPlayer()
            onError("Invalid audio URL. Must start with http:// or https://")
            return
        }

        synthEngine.pause()
        releaseMediaPlayer()
        activeUrl = cleanUrl
        isUrlPrepared = false

        scope.launch(Dispatchers.Main) {
            try {
                val mp = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    setOnPreparedListener { player ->
                        isUrlPrepared = true
                        val durSec = (player.duration / 1000).takeIf { it > 0 } ?: 180
                        try {
                            player.start()
                            onPrepared(durSec)
                        } catch (e: Throwable) {
                            onError("Could not start playback: ${e.message ?: "Audio error"}")
                        }
                    }
                    setOnCompletionListener {
                        onCompletion()
                    }
                    setOnErrorListener { _, what, extra ->
                        isUrlPrepared = false
                        val detail = when (what) {
                            MediaPlayer.MEDIA_ERROR_SERVER_DIED -> "Audio server connection lost"
                            else -> "Unable to play this audio link (code $what/$extra). Verify the MP3 URL is direct and publicly accessible."
                        }
                        onError(detail)
                        true
                    }
                    setDataSource(cleanUrl)
                    prepareAsync()
                }
                mediaPlayer = mp
            } catch (t: Throwable) {
                isUrlPrepared = false
                releaseMediaPlayer()
                onError("Invalid or blocked audio URL: ${t.message ?: "Unable to stream"}")
            }
        }
    }

    fun pause() {
        synthEngine.pause()
        try {
            if (isUrlPrepared && mediaPlayer?.isPlaying == true) {
                mediaPlayer?.pause()
            }
        } catch (_: Throwable) {
        }
    }

    fun resume(synthMood: String) {
        if (activeUrl != null) {
            try {
                if (isUrlPrepared) {
                    mediaPlayer?.start()
                } else {
                    play(activeUrl!!, synthMood)
                }
            } catch (t: Throwable) {
                onError("Could not resume audio: ${t.message ?: "Playback error"}")
            }
        } else {
            synthEngine.start(synthMood)
        }
    }

    fun seekTo(seconds: Int) {
        if (activeUrl != null && isUrlPrepared) {
            try {
                mediaPlayer?.seekTo((seconds * 1000).coerceAtLeast(0))
            } catch (_: Throwable) {
            }
        }
    }

    fun getCurrentPositionSeconds(): Int? {
        return if (activeUrl != null && isUrlPrepared) {
            try {
                (mediaPlayer?.currentPosition ?: 0) / 1000
            } catch (_: Throwable) {
                null
            }
        } else null
    }

    fun release() {
        synthEngine.release()
        releaseMediaPlayer()
    }

    private fun releaseMediaPlayer() {
        try {
            mediaPlayer?.setOnPreparedListener(null)
            mediaPlayer?.setOnCompletionListener(null)
            mediaPlayer?.setOnErrorListener(null)
            mediaPlayer?.reset()
            mediaPlayer?.release()
        } catch (_: Throwable) {
        } finally {
            mediaPlayer = null
        }
    }
}
