package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

class SynthAudioEngine(private val scope: CoroutineScope) {

    private var playJob: Job? = null

    @Volatile
    private var currentMood: String = "AMBIENT_CYAN"

    @Volatile
    private var isActivePlaying: Boolean = false

    fun start(mood: String) {
        currentMood = mood
        if (isActivePlaying && playJob?.isActive == true) return
        isActivePlaying = true
        playJob?.cancel()
        playJob = scope.launch(Dispatchers.IO) {
            runAudioLoop()
        }
    }

    fun updateMood(mood: String) {
        currentMood = mood
    }

    fun pause() {
        isActivePlaying = false
        playJob?.cancel()
        playJob = null
    }

    fun release() {
        pause()
    }

    private suspend fun CoroutineScope.runAudioLoop() {
        val sampleRate = 22050
        val bufferSamples = 2048
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(bufferSamples * 2)

        var track: AudioTrack? = null
        try {
            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(minBuf)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            track.play()

            val buffer = ShortArray(bufferSamples)
            var sampleCursor = 0L

            while (isActive && isActivePlaying) {
                val chords = chordsForMood(currentMood)
                val stepSeconds = when (currentMood) {
                    "UPBEAT_PULSE" -> 0.5
                    "LOFI_CHILL" -> 1.6
                    "PODCAST_VOICE" -> 2.4
                    else -> 2.0
                }
                val stepSamples = (sampleRate * stepSeconds).toLong().coerceAtLeast(1L)

                for (i in 0 until bufferSamples) {
                    val t = sampleCursor.toDouble() / sampleRate.toDouble()
                    val chordIdx = ((sampleCursor / stepSamples) % chords.size).toInt()
                    val stepPhase = (sampleCursor % stepSamples).toDouble() / stepSamples.toDouble()
                    val env = if (currentMood == "UPBEAT_PULSE") {
                        exp(-stepPhase * 3.2) * 0.85 + 0.15
                    } else {
                        val attack = (stepPhase * 6.0).coerceAtMost(1.0)
                        val release = ((1.0 - stepPhase) * 4.0).coerceAtMost(1.0)
                        attack * release
                    }

                    val freqs = chords[chordIdx]
                    var wave = 0.0
                    for (f in freqs) {
                        wave += sin(2.0 * PI * f * t)
                    }
                    wave /= freqs.size.coerceAtLeast(1)

                    // Subtle warm sub-harmonic pad
                    val sub = sin(2.0 * PI * (freqs[0] * 0.5) * t) * 0.25
                    val gain = if (currentMood == "PODCAST_VOICE") 0.06 else 0.14
                    val mixed = ((wave + sub) * env * gain).coerceIn(-0.95, 0.95)
                    buffer[i] = (mixed * Short.MAX_VALUE).toInt().toShort()
                    sampleCursor++
                }
                track.write(buffer, 0, bufferSamples)
            }
        } catch (t: Throwable) {
            Log.w("SynthAudioEngine", "Audio output unavailable: ${t.message}")
        } finally {
            try {
                track?.pause()
                track?.flush()
                track?.release()
            } catch (_: Throwable) {
            }
        }
    }

    private fun chordsForMood(mood: String): List<List<Double>> {
        return when (mood) {
            "ROMANTIC_PIANO" -> listOf(
                listOf(220.0, 261.63, 329.63, 392.0), // Am7
                listOf(174.61, 220.0, 261.63, 329.63), // Fmaj7
                listOf(196.0, 246.94, 293.66, 392.0), // G6
                listOf(164.81, 196.0, 246.94, 329.63) // Em7
            )
            "LOFI_CHILL" -> listOf(
                listOf(196.0, 233.08, 293.66, 349.23), // Gm7
                listOf(146.83, 220.0, 261.63, 329.63), // Dm9
                listOf(155.56, 196.0, 233.08, 293.66), // Ebmaj7
                listOf(174.61, 220.0, 261.63, 349.23)  // Fmaj7
            )
            "UPBEAT_PULSE" -> listOf(
                listOf(261.63, 329.63, 392.0),
                listOf(293.66, 349.23, 440.0),
                listOf(329.63, 392.0, 493.88),
                listOf(246.94, 293.66, 392.0)
            )
            "PODCAST_VOICE" -> listOf(
                listOf(146.83, 220.0, 293.66),
                listOf(164.81, 246.94, 329.63)
            )
            else -> listOf( // AMBIENT_CYAN
                listOf(174.61, 220.0, 261.63, 329.63),
                listOf(196.0, 246.94, 293.66, 392.0),
                listOf(220.0, 261.63, 329.63, 440.0),
                listOf(164.81, 220.0, 261.63, 329.63)
            )
        }
    }
}
