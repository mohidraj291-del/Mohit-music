package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import com.example.R
import com.example.data.model.AuthenticatedUserInfo
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.AvatarGradEnd
import com.example.ui.theme.AvatarGradStart
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.SuccessMint
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun TopHeaderBar(
    user: AuthenticatedUserInfo,
    isPremium: Boolean,
    isOnline: Boolean,
    onAvatarClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val initials = user.name
        .trim()
        .split(" ")
        .filter { it.isNotBlank() }
        .take(2)
        .joinToString("") { it.first().uppercaseChar().toString() }
        .ifEmpty { "M" }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .background(PitchBlack)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Box(
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .clickable(onClick = onAvatarClick)
                .testTag("profile_avatar_button")
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(AvatarGradStart, AvatarGradEnd)))
                    .border(
                        width = 1.5.dp,
                        color = if (isPremium) AmberGlow else CyanAccent,
                        shape = CircleShape
                    )
            ) {
                if (user.photoUrl.isNotBlank()) {
                    SubcomposeAsyncImage(
                        model = user.photoUrl,
                        contentDescription = stringResource(R.string.cd_profile_avatar),
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                        error = {
                            Text(
                                text = initials,
                                color = PitchBlack,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 14.sp
                                )
                            )
                        }
                    )
                } else {
                    Text(
                        text = initials,
                        color = PitchBlack,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp
                        )
                    )
                }
            }

            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(11.dp)
                    .clip(CircleShape)
                    .background(PitchBlack)
                    .padding(2.dp)
                    .clip(CircleShape)
                    .background(if (isOnline) SuccessMint else TextSecondary)
                    .testTag("header_online_indicator")
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = Icons.Filled.GraphicEq,
                contentDescription = null,
                tint = CyanAccent,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = "MOHIT",
                color = TextPrimary,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "Music",
                color = CyanAccent,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Medium),
                maxLines = 1
            )
        }

        PlanStatusBadge(
            isPremium = isPremium,
            onClick = onAvatarClick,
            modifier = Modifier.testTag("header_plan_badge")
        )
    }
}

@Composable
fun PlanStatusBadge(
    isPremium: Boolean,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val bgColor = if (isPremium) CyanAccent.copy(alpha = 0.18f) else SurfaceCard
    val borderColor = if (isPremium) CyanAccent else SurfaceBorder
    val contentColor = if (isPremium) CyanAccent else TextSecondary

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(50),
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor),
        modifier = modifier.then(
            if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
        )
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        ) {
            if (isPremium) {
                Icon(
                    imageVector = Icons.Filled.WorkspacePremium,
                    contentDescription = "Premium plan",
                    tint = CyanAccent,
                    modifier = Modifier.size(14.dp)
                )
            }
            Text(
                text = stringResource(if (isPremium) R.string.badge_premium else R.string.badge_free),
                color = contentColor,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.8.sp
                )
            )
        }
    }
}
