package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import com.example.R
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanBright
import com.example.ui.theme.PitchBlack

@Composable
fun MediaCoverArt(
    artworkKey: String,
    contentDescription: String,
    modifier: Modifier = Modifier,
    coverImageUrl: String = ""
) {
    if (coverImageUrl.isNotBlank()) {
        SubcomposeAsyncImage(
            model = coverImageUrl,
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = modifier,
            loading = {
                FallbackCoverArt(artworkKey = artworkKey, contentDescription = contentDescription, modifier = Modifier.fillMaxSize())
            },
            error = {
                FallbackCoverArt(artworkKey = artworkKey, contentDescription = contentDescription, modifier = Modifier.fillMaxSize())
            }
        )
    } else {
        FallbackCoverArt(artworkKey = artworkKey, contentDescription = contentDescription, modifier = modifier)
    }
}

@Composable
private fun FallbackCoverArt(
    artworkKey: String,
    contentDescription: String,
    modifier: Modifier = Modifier
) {
    when (artworkKey) {
        "hero_soundtrack" -> {
            Image(
                painter = painterResource(id = R.drawable.img_hero_soundtrack_1795194967498),
                contentDescription = contentDescription,
                contentScale = ContentScale.Crop,
                modifier = modifier
            )
        }
        "mithoon" -> {
            Image(
                painter = painterResource(id = R.drawable.img_cover_mithoon_1795194968502),
                contentDescription = contentDescription,
                contentScale = ContentScale.Crop,
                modifier = modifier
            )
        }
        "lofi" -> {
            Image(
                painter = painterResource(id = R.drawable.img_cover_lofi_1795194968187),
                contentDescription = contentDescription,
                contentScale = ContentScale.Crop,
                modifier = modifier
            )
        }
        "podcast" -> {
            Image(
                painter = painterResource(id = R.drawable.img_cover_podcast_1795194967518),
                contentDescription = contentDescription,
                contentScale = ContentScale.Crop,
                modifier = modifier
            )
        }
        else -> {
            ProceduralCoverCanvas(artworkKey = artworkKey, modifier = modifier)
        }
    }
}

@Composable
private fun ProceduralCoverCanvas(
    artworkKey: String,
    modifier: Modifier = Modifier
) {
    val (c1, c2, ringColor) = when (artworkKey) {
        "gradient_sunset" -> Triple(Color(0xFF1F122B), Color(0xFF832A48), Color(0xFFFF8C66))
        "gradient_indigo" -> Triple(Color(0xFF0E1630), Color(0xFF2B2D7A), Color(0xFF638DFF))
        "gradient_emerald" -> Triple(Color(0xFF071F1E), Color(0xFF0E5A4F), Color(0xFF2EE59D))
        else -> Triple(Color(0xFF081B22), Color(0xFF0E4954), CyanAccent)
    }

    Box(
        modifier = modifier.background(
            brush = Brush.linearGradient(
                colors = listOf(c1, c2),
                start = Offset.Zero,
                end = Offset(400f, 400f)
            )
        )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width * 0.72f, size.height * 0.34f)
            val maxR = size.minDimension * 0.65f
            listOf(0.32f, 0.58f, 0.85f).forEachIndexed { idx, factor ->
                drawCircle(
                    color = ringColor.copy(alpha = 0.28f - idx * 0.07f),
                    radius = maxR * factor,
                    center = center,
                    style = Stroke(width = 2.5.dp.toPx())
                )
            }
            drawCircle(
                color = ringColor.copy(alpha = 0.14f),
                radius = size.minDimension * 0.25f,
                center = Offset(size.width * 0.22f, size.height * 0.78f)
            )
        }
    }
}

@Composable
fun AllAccessBadge(
    modifier: Modifier = Modifier
) {
    Surface(
        color = CyanAccent.copy(alpha = 0.16f),
        shape = RoundedCornerShape(4.dp),
        modifier = modifier
    ) {
        Text(
            text = "ALL-ACCESS",
            color = CyanBright,
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 9.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.7.sp
            ),
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun CircularTealPlayButton(
    isPlaying: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    iconSize: Dp = 24.dp,
    semiTransparent: Boolean = false,
    isBuffering: Boolean = false
) {
    val bgColor = if (semiTransparent) Color(0xCC0D1418) else CyanAccent
    val iconColor = if (semiTransparent) CyanAccent else PitchBlack

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .minimumInteractiveComponentSize()
            .size(size)
            .clip(CircleShape)
            .background(bgColor)
            .clickable(onClick = onClick)
    ) {
        if (isBuffering) {
            CircularProgressIndicator(
                color = iconColor,
                strokeWidth = 2.dp,
                modifier = Modifier.size(iconSize * 0.85f)
            )
        } else {
            Icon(
                imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = if (isPlaying) "Pause" else "Play",
                tint = iconColor,
                modifier = Modifier.size(iconSize)
            )
        }
    }
}
