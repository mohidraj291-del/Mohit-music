package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PitchBlack = Color(0xFF000000)
val SurfaceDark = Color(0xFF121417)
val SurfaceCard = Color(0xFF191D22)
val SurfaceElevated = Color(0xFF222830)
val SurfaceBorder = Color(0xFF2A313B)

val CyanAccent = Color(0xFF00D2D3)
val CyanBright = Color(0xFF45E8E9)
val CyanDeep = Color(0xFF008F90)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFA0A8B4)
val TextMuted = Color(0xFF6B7380)

val AvatarGradStart = Color(0xFF00D2D3)
val AvatarGradEnd = Color(0xFF3B82F6)

val ErrorCoral = Color(0xFFFF5E6C)
val SuccessMint = Color(0xFF2EE59D)
val AmberGlow = Color(0xFFFFB84D)
