package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.HybridAudioPlayer
import com.example.data.model.AppConfig
import com.example.data.model.AudioEqPreset
import com.example.data.model.AuthenticatedUserInfo
import com.example.data.model.MusicTrack
import com.example.data.model.TrackSource
import com.example.data.model.UserRtdbProfile
import com.example.data.remote.MusicSearchService
import com.example.data.remote.OnlineMusicSearchService
import com.example.data.repository.MusicCloudRepository
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class PlaybackState(
    val currentTrack: MusicTrack? = null,
    val queue: List<MusicTrack> = emptyList(),
    val currentIndex: Int = -1,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val positionSeconds: Int = 0,
    val durationSeconds: Int = 0,
    val isShuffle: Boolean = false,
    val isRepeat: Boolean = false,
    val playbackError: String? = null,
    val activeEqPreset: AudioEqPreset = AudioEqPreset.STANDARD
)

data class MohitMusicUiState(
    val user: AuthenticatedUserInfo,
    val rtdbProfile: UserRtdbProfile,
    val appConfig: AppConfig = AppConfig(),
    val isDatabaseConfigured: Boolean = false,
    val databaseStatusLabel: String = "",
    val searchQuery: String = "",
    val isSearchActive: Boolean = false,
    val isSearching: Boolean = false,
    val isLoadingHomeFeed: Boolean = true,
    val homeFeedTracks: List<MusicTrack> = emptyList(),
    val homeFeedSource: TrackSource = TrackSource.AUDIUS,
    val homeFeedError: String? = null,
    val searchResults: List<MusicTrack> = emptyList(),
    val searchSource: TrackSource = TrackSource.AUDIUS,
    val isSearchFallbackUsed: Boolean = false,
    val searchError: String? = null,
    val playback: PlaybackState = PlaybackState(),
    val statusToast: String? = null
) {
    val isPremium: Boolean get() = rtdbProfile.isPremium
    val isOnline: Boolean get() = rtdbProfile.online
}

@OptIn(FlowPreview::class)
class MainViewModel(
    private val currentUser: AuthenticatedUserInfo,
    private val cloudRepository: MusicCloudRepository,
    private val searchService: MusicSearchService = OnlineMusicSearchService(),
    private val debounceMillis: Long = DEFAULT_SEARCH_DEBOUNCE_MS,
    private val enableAudioEngine: Boolean = true
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        MohitMusicUiState(
            user = currentUser,
            rtdbProfile = UserRtdbProfile(
                uid = currentUser.uid,
                name = currentUser.name,
                email = currentUser.email,
                photoURL = currentUser.photoUrl,
                isPremium = false,
                online = false,
                deviceInfo = MusicCloudRepository.defaultDeviceInfo()
            ),
            isDatabaseConfigured = cloudRepository.isDatabaseConfigured,
            databaseStatusLabel = cloudRepository.databaseStatusLabel
        )
    )
    val uiState: StateFlow<MohitMusicUiState> = _uiState.asStateFlow()

    private val searchQueryFlow = MutableStateFlow("")
    private var positionTickerJob: Job? = null
    private var detachPresenceListener: (() -> Unit)? = null

    private val audioPlayer: HybridAudioPlayer? = if (enableAudioEngine) {
        HybridAudioPlayer(
            scope = viewModelScope,
            onPrepared = { realDurationSec ->
                _uiState.update { state ->
                    val currentDur = state.playback.currentTrack?.durationSeconds ?: 180
                    val finalDuration = when {
                        realDurationSec > 0 -> realDurationSec
                        currentDur > 0 -> currentDur
                        else -> 180
                    }
                    state.copy(
                        playback = state.playback.copy(
                            isBuffering = false,
                            isPlaying = true,
                            durationSeconds = finalDuration,
                            playbackError = null
                        )
                    )
                }
            },
            onCompletion = {
                handleTrackCompleted()
            },
            onError = { errMsg ->
                _uiState.update { state ->
                    state.copy(
                        playback = state.playback.copy(
                            isBuffering = false,
                            isPlaying = false,
                            playbackError = errMsg
                        ),
                        statusToast = errMsg
                    )
                }
            }
        )
    } else null

    init {
        startCloudSync()
        startDebouncedSearch()
        loadHomeFeed()
    }

    private fun startCloudSync() {
        viewModelScope.launch {
            cloudRepository.syncUserProfileAndPresence(currentUser)
        }
        detachPresenceListener = cloudRepository.attachPresenceDisconnectHandler(currentUser.uid)

        viewModelScope.launch {
            cloudRepository.observeAppConfig().collect { config ->
                if (!config.appEnabled) {
                    pausePlaybackImmediately()
                }
                _uiState.update { it.copy(appConfig = config) }
            }
        }

        viewModelScope.launch {
            cloudRepository.observeUserProfile(currentUser.uid).collect { profile ->
                _uiState.update { state ->
                    val resolvedPreset = if (!profile.isPremium && state.playback.activeEqPreset.requiresPremium) {
                        AudioEqPreset.STANDARD
                    } else {
                        state.playback.activeEqPreset
                    }
                    state.copy(
                        rtdbProfile = profile.copy(
                            uid = currentUser.uid,
                            name = profile.name.ifBlank { currentUser.name },
                            email = profile.email.ifBlank { currentUser.email },
                            photoURL = profile.photoURL.ifBlank { currentUser.photoUrl }
                        ),
                        playback = state.playback.copy(activeEqPreset = resolvedPreset)
                    )
                }
            }
        }
    }

    private fun startDebouncedSearch() {
        viewModelScope.launch {
            searchQueryFlow
                .drop(1)
                .debounce(debounceMillis)
                .distinctUntilChanged()
                .collectLatest { query ->
                    executeSearch(query)
                }
        }
    }

    fun loadHomeFeed() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingHomeFeed = true, homeFeedError = null) }
            val response = searchService.fetchHomeFeedTracks()
            _uiState.update { state ->
                state.copy(
                    isLoadingHomeFeed = false,
                    homeFeedTracks = response.tracks,
                    homeFeedSource = response.source,
                    homeFeedError = response.errorMessage
                )
            }
        }
    }

    fun onSearchQueryChanged(query: String) {
        val trimmed = query.trim()
        _uiState.update { state ->
            state.copy(
                searchQuery = query,
                isSearchActive = trimmed.length >= 2,
                isSearching = trimmed.length >= 2,
                searchResults = if (trimmed.length < 2) emptyList() else state.searchResults,
                searchError = if (trimmed.length < 2) null else state.searchError
            )
        }
        searchQueryFlow.value = query
    }

    fun triggerImmediateSearch(query: String) {
        onSearchQueryChanged(query)
        viewModelScope.launch {
            executeSearch(query)
        }
    }

    private suspend fun executeSearch(rawQuery: String) {
        val clean = rawQuery.trim()
        if (clean.length < 2) {
            _uiState.update {
                it.copy(
                    isSearchActive = false,
                    isSearching = false,
                    searchResults = emptyList(),
                    searchError = null
                )
            }
            return
        }

        _uiState.update { it.copy(isSearchActive = true, isSearching = true, searchError = null) }
        val response = searchService.searchTracks(clean)
        // Guard against stale response if user cleared the search box while network ran
        if (_uiState.value.searchQuery.trim() != clean) return

        _uiState.update { state ->
            state.copy(
                isSearching = false,
                searchResults = response.tracks,
                searchSource = response.source,
                isSearchFallbackUsed = response.isFallbackUsed,
                searchError = response.errorMessage
            )
        }
    }

    fun playTrack(track: MusicTrack, contextList: List<MusicTrack> = emptyList()) {
        if (!_uiState.value.appConfig.appEnabled) {
            _uiState.update { it.copy(statusToast = "Playback disabled during maintenance.") }
            return
        }

        val currentQueue = if (contextList.isNotEmpty()) {
            if (contextList.any { it.id == track.id }) contextList else listOf(track) + contextList
        } else {
            val existing = _uiState.value.playback.queue
            if (existing.any { it.id == track.id }) existing else existing + track
        }
        val targetIndex = currentQueue.indexOfFirst { it.id == track.id }.coerceAtLeast(0)

        _uiState.update { state ->
            state.copy(
                playback = state.playback.copy(
                    currentTrack = track,
                    queue = currentQueue,
                    currentIndex = targetIndex,
                    isPlaying = true,
                    isBuffering = track.streamUrl.isNotBlank(),
                    positionSeconds = 0,
                    durationSeconds = track.durationSeconds.coerceAtLeast(1),
                    playbackError = null
                )
            )
        }

        audioPlayer?.play(track.streamUrl, synthMood = moodForPreset(_uiState.value.playback.activeEqPreset))
        if (audioPlayer != null) startPositionTicker()
    }

    fun addToQueue(track: MusicTrack) {
        if (!_uiState.value.appConfig.appEnabled) return
        val pb = _uiState.value.playback
        if (pb.currentTrack == null) {
            playTrack(track, listOf(track))
            return
        }
        if (pb.queue.any { it.id == track.id }) {
            _uiState.update { it.copy(statusToast = "\"${track.title}\" is already in queue") }
            return
        }
        _uiState.update { state ->
            state.copy(
                playback = state.playback.copy(queue = state.playback.queue + track),
                statusToast = "Added \"${track.title}\" to Up Next"
            )
        }
    }

    fun removeFromQueue(trackId: String) {
        _uiState.update { state ->
            val pb = state.playback
            if (pb.currentTrack?.id == trackId) return@update state
            val updatedQueue = pb.queue.filterNot { it.id == trackId }
            val updatedIndex = updatedQueue.indexOfFirst { it.id == pb.currentTrack?.id }
            state.copy(
                playback = pb.copy(
                    queue = updatedQueue,
                    currentIndex = updatedIndex
                )
            )
        }
    }

    fun clearUpcomingQueue() {
        _uiState.update { state ->
            val current = state.playback.currentTrack
            val updatedQueue = if (current != null) listOf(current) else emptyList()
            state.copy(
                playback = state.playback.copy(
                    queue = updatedQueue,
                    currentIndex = if (current != null) 0 else -1
                ),
                statusToast = "Cleared upcoming queue"
            )
        }
    }

    fun togglePlayPause() {
        if (!_uiState.value.appConfig.appEnabled) {
            pausePlaybackImmediately()
            return
        }
        val pb = _uiState.value.playback
        val track = pb.currentTrack ?: return
        val nextPlaying = !pb.isPlaying
        _uiState.update {
            it.copy(
                playback = it.playback.copy(
                    isPlaying = nextPlaying,
                    playbackError = null
                )
            )
        }
        if (nextPlaying) {
            audioPlayer?.resume(moodForPreset(pb.activeEqPreset))
            if (audioPlayer != null) startPositionTicker()
        } else {
            audioPlayer?.pause()
            positionTickerJob?.cancel()
        }
    }

    fun skipNext() {
        val pb = _uiState.value.playback
        if (pb.queue.isEmpty()) return
        val nextIdx = if (pb.isShuffle && pb.queue.size > 1) {
            pb.queue.indices.filter { it != pb.currentIndex }.random()
        } else {
            (pb.currentIndex + 1) % pb.queue.size
        }
        playTrack(pb.queue[nextIdx], pb.queue)
    }

    fun skipPrevious() {
        val pb = _uiState.value.playback
        if (pb.queue.isEmpty()) return
        if (pb.positionSeconds > 4) {
            seekTo(0)
            return
        }
        val prevIdx = if (pb.currentIndex <= 0) pb.queue.lastIndex else pb.currentIndex - 1
        playTrack(pb.queue[prevIdx], pb.queue)
    }

    fun seekTo(seconds: Int) {
        val pb = _uiState.value.playback
        val clamped = seconds.coerceIn(0, pb.durationSeconds.coerceAtLeast(1))
        audioPlayer?.seekTo(clamped)
        _uiState.update {
            it.copy(playback = it.playback.copy(positionSeconds = clamped))
        }
    }

    fun toggleShuffle() {
        _uiState.update {
            it.copy(playback = it.playback.copy(isShuffle = !it.playback.isShuffle))
        }
    }

    fun toggleRepeat() {
        _uiState.update {
            it.copy(playback = it.playback.copy(isRepeat = !it.playback.isRepeat))
        }
    }

    fun selectEqPreset(preset: AudioEqPreset) {
        if (preset.requiresPremium && !_uiState.value.isPremium) {
            _uiState.update {
                it.copy(statusToast = "${preset.label} requires Premium access (set /users/${currentUser.uid}/isPremium = true)")
            }
            return
        }
        _uiState.update {
            it.copy(
                playback = it.playback.copy(activeEqPreset = preset),
                statusToast = "Audio profile: ${preset.label}"
            )
        }
    }

    fun clearStatusToast() {
        _uiState.update { it.copy(statusToast = null) }
    }

    suspend fun prepareForSignOut() {
        pausePlaybackImmediately()
        cloudRepository.markOffline(currentUser.uid)
    }

    private fun pausePlaybackImmediately() {
        positionTickerJob?.cancel()
        audioPlayer?.pause()
        _uiState.update { state ->
            state.copy(
                playback = state.playback.copy(
                    isPlaying = false,
                    isBuffering = false
                )
            )
        }
    }

    private fun handleTrackCompleted() {
        val pb = _uiState.value.playback
        if (pb.isRepeat && pb.currentTrack != null) {
            playTrack(pb.currentTrack, pb.queue)
        } else if (pb.queue.size > 1) {
            skipNext()
        } else {
            _uiState.update {
                it.copy(
                    playback = it.playback.copy(
                        isPlaying = false,
                        positionSeconds = it.playback.durationSeconds
                    )
                )
            }
        }
    }

    private fun startPositionTicker() {
        positionTickerJob?.cancel()
        positionTickerJob = viewModelScope.launch {
            while (isActive) {
                delay(500L)
                val pb = _uiState.value.playback
                if (!pb.isPlaying || pb.isBuffering) continue
                val realPos = audioPlayer?.getCurrentPositionSeconds()
                if (realPos != null) {
                    _uiState.update {
                        it.copy(
                            playback = it.playback.copy(
                                positionSeconds = realPos.coerceIn(0, it.playback.durationSeconds.coerceAtLeast(1))
                            )
                        )
                    }
                }
            }
        }
    }

    private fun moodForPreset(preset: AudioEqPreset): String = when (preset) {
        AudioEqPreset.DEEP_BASS -> "UPBEAT_PULSE"
        AudioEqPreset.STUDIO_CRISP -> "ROMANTIC_PIANO"
        AudioEqPreset.SPATIAL_HALL -> "LOFI_CHILL"
        AudioEqPreset.STANDARD -> "AMBIENT_CYAN"
    }

    override fun onCleared() {
        super.onCleared()
        positionTickerJob?.cancel()
        detachPresenceListener?.invoke()
        audioPlayer?.release()
    }

    companion object {
        const val DEFAULT_SEARCH_DEBOUNCE_MS = 400L
    }
}
