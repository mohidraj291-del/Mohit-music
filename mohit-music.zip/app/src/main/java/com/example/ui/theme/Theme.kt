package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val MohitDarkColorScheme = darkColorScheme(
    primary = CyanAccent,
    onPrimary = PitchBlack,
    primaryContainer = CyanDeep,
    onPrimaryContainer = TextPrimary,
    secondary = CyanBright,
    onSecondary = PitchBlack,
    secondaryContainer = SurfaceElevated,
    onSecondaryContainer = TextPrimary,
    tertiary = AmberGlow,
    onTertiary = PitchBlack,
    background = PitchBlack,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceCard,
    onSurfaceVariant = TextSecondary,
    outline = SurfaceBorder,
    outlineVariant = SurfaceElevated,
    error = ErrorCoral,
    onError = PitchBlack
)

private val MohitShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun MohitMusicTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = MohitDarkColorScheme,
        typography = MohitTypography,
        shapes = MohitShapes,
        content = content
    )
}
