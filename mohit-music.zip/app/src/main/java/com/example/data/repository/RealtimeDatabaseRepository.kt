package com.example.data.repository

import android.os.Build
import android.util.Log
import com.example.BuildConfig
import com.example.data.model.AppConfig
import com.example.data.model.AuthenticatedUserInfo
import com.example.data.model.UserRtdbProfile
import com.google.firebase.FirebaseApp
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.ServerValue
import com.google.firebase.database.Transaction
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.tasks.await
import kotlin.coroutines.resume

interface MusicCloudRepository {
    val isDatabaseConfigured: Boolean
    val databaseStatusLabel: String

    suspend fun syncUserProfileAndPresence(user: AuthenticatedUserInfo, deviceInfo: String = defaultDeviceInfo())
    fun attachPresenceDisconnectHandler(uid: String): () -> Unit
    suspend fun markOffline(uid: String)
    fun observeAppConfig(): Flow<AppConfig>
    fun observeUserProfile(uid: String): Flow<UserRtdbProfile>

    companion object {
        fun defaultDeviceInfo(): String {
            val manufacturer = Build.MANUFACTURER?.trim().orEmpty()
            val model = Build.MODEL?.trim().orEmpty()
            val release = Build.VERSION.RELEASE?.trim().orEmpty()
            val hardware = listOf(manufacturer, model).filter { it.isNotBlank() }.joinToString(" ").ifBlank { "Android Device" }
            return if (release.isNotBlank()) "$hardware (Android $release)" else hardware
        }
    }
}

class FirebaseRealtimeDatabaseRepository(
    private val database: FirebaseDatabase? = resolveFirebaseDatabase()
) : MusicCloudRepository {

    override val isDatabaseConfigured: Boolean
        get() = database != null

    override val databaseStatusLabel: String
        get() {
            val envUrl = BuildConfig.FIREBASE_DATABASE_URL.trim()
            return when {
                database != null -> envUrl.takeIf { it.isValidDatabaseUrl() }
                    ?: runCatching { FirebaseApp.getInstance().options.databaseUrl }.getOrNull()
                    ?: "Connected to Firebase Realtime Database"
                else -> "RTDB URL pending: Set FIREBASE_DATABASE_URL in Secrets panel"
            }
        }

    override suspend fun syncUserProfileAndPresence(user: AuthenticatedUserInfo, deviceInfo: String) {
        val db = database ?: return
        val userRef = db.getReference("users").child(user.uid)

        // Register onDisconnect handler first so abrupt termination marks user offline and updates lastSeen
        runCatching {
            userRef.onDisconnect().updateChildren(
                mapOf(
                    "online" to false,
                    "lastSeen" to ServerValue.TIMESTAMP
                )
            ).await()
        }.onFailure {
            Log.w(TAG, "Failed registering initial onDisconnect handler: ${it.message}")
        }

        // Transactionally write profile fields without ever overwriting an existing isPremium flag
        suspendCancellableCoroutine<Unit> { cont ->
            userRef.runTransaction(object : Transaction.Handler {
                override fun doTransaction(currentData: MutableData): Transaction.Result {
                    val existing = (currentData.value as? Map<*, *>)?.toMutableMap() ?: mutableMapOf<Any?, Any?>()
                    existing["name"] = user.name
                    existing["email"] = user.email
                    existing["photoURL"] = user.photoUrl
                    existing["lastSeen"] = ServerValue.TIMESTAMP
                    existing["deviceInfo"] = deviceInfo
                    existing["online"] = true
                    if (!existing.containsKey("isPremium") || existing["isPremium"] == null) {
                        existing["isPremium"] = false
                    }
                    currentData.value = existing
                    return Transaction.success(currentData)
                }

                override fun onComplete(
                    error: DatabaseError?,
                    committed: Boolean,
                    currentData: DataSnapshot?
                ) {
                    if (error != null) {
                        Log.w(TAG, "User profile RTDB transaction warning: ${error.message}")
                    }
                    if (cont.isActive) cont.resume(Unit)
                }
            })
        }
    }

    override fun attachPresenceDisconnectHandler(uid: String): () -> Unit {
        val db = database ?: return {}
        val connectedRef = db.getReference(".info/connected")
        val userRef = db.getReference("users").child(uid)

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val connected = snapshot.getValue(Boolean::class.java) ?: false
                if (!connected) return

                userRef.onDisconnect().updateChildren(
                    mapOf(
                        "online" to false,
                        "lastSeen" to ServerValue.TIMESTAMP
                    )
                )
                userRef.updateChildren(
                    mapOf(
                        "online" to true,
                        "lastSeen" to ServerValue.TIMESTAMP
                    )
                )
            }

            override fun onCancelled(error: DatabaseError) {
                Log.w(TAG, "RTDB .info/connected listener cancelled: ${error.message}")
            }
        }
        connectedRef.addValueEventListener(listener)
        return { connectedRef.removeEventListener(listener) }
    }

    override suspend fun markOffline(uid: String) {
        val db = database ?: return
        runCatching {
            db.getReference("users").child(uid).updateChildren(
                mapOf(
                    "online" to false,
                    "lastSeen" to ServerValue.TIMESTAMP
                )
            ).await()
        }.onFailure {
            Log.w(TAG, "Could not mark user offline before sign-out: ${it.message}")
        }
    }

    override fun observeAppConfig(): Flow<AppConfig> {
        val db = database ?: return flowOf(AppConfig())
        val configRef = db.getReference("appConfig")
        return callbackFlow {
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (!snapshot.exists()) {
                        trySend(AppConfig())
                        return
                    }
                    val appEnabled = snapshot.child("appEnabled").getValue(Boolean::class.java) ?: true
                    val maintenanceMsg = snapshot.child("maintenanceMessage").getValue(String::class.java).orEmpty()
                    val noticeText = snapshot.child("noticeText").getValue(String::class.java).orEmpty()
                    trySend(
                        AppConfig(
                            appEnabled = appEnabled,
                            maintenanceMessage = maintenanceMsg,
                            noticeText = noticeText
                        )
                    )
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.w(TAG, "RTDB /appConfig listener cancelled: ${error.message}")
                    trySend(AppConfig())
                }
            }
            configRef.addValueEventListener(listener)
            awaitClose { configRef.removeEventListener(listener) }
        }
    }

    override fun observeUserProfile(uid: String): Flow<UserRtdbProfile> {
        val db = database ?: return flowOf(UserRtdbProfile(uid = uid))
        val userRef = db.getReference("users").child(uid)
        return callbackFlow {
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val profile = UserRtdbProfile(
                        uid = uid,
                        name = snapshot.child("name").getValue(String::class.java).orEmpty(),
                        email = snapshot.child("email").getValue(String::class.java).orEmpty(),
                        photoURL = snapshot.child("photoURL").getValue(String::class.java).orEmpty(),
                        isPremium = snapshot.child("isPremium").getValue(Boolean::class.java) ?: false,
                        online = snapshot.child("online").getValue(Boolean::class.java) ?: false,
                        lastSeen = (snapshot.child("lastSeen").value as? Number)?.toLong() ?: 0L,
                        deviceInfo = snapshot.child("deviceInfo").getValue(String::class.java).orEmpty()
                    )
                    trySend(profile)
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.w(TAG, "RTDB /users/$uid listener cancelled: ${error.message}")
                }
            }
            userRef.addValueEventListener(listener)
            awaitClose { userRef.removeEventListener(listener) }
        }
    }

    companion object {
        private const val TAG = "RtdbRepository"

        private fun String.isValidDatabaseUrl(): Boolean {
            return isNotBlank() &&
                !contains("YOUR_FIREBASE_DATABASE_URL", ignoreCase = true) &&
                (startsWith("https://") || startsWith("http://"))
        }

        fun resolveFirebaseDatabase(): FirebaseDatabase? {
            val envUrl = BuildConfig.FIREBASE_DATABASE_URL.trim()
            if (envUrl.isValidDatabaseUrl()) {
                return runCatching { FirebaseDatabase.getInstance(envUrl) }
                    .onFailure { Log.e(TAG, "Invalid FIREBASE_DATABASE_URL: $envUrl", it) }
                    .getOrNull()
            }
            val optionsUrl = runCatching { FirebaseApp.getInstance().options.databaseUrl?.trim() }.getOrNull()
            if (!optionsUrl.isNullOrBlank() && optionsUrl.isValidDatabaseUrl()) {
                return runCatching { FirebaseDatabase.getInstance() }.getOrNull()
            }
            return null
        }
    }
}
