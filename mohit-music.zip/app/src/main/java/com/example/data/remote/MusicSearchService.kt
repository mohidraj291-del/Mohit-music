package com.example.data.remote

import com.example.data.model.MusicTrack
import com.example.data.model.SearchResponse
import com.example.data.model.TrackSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

interface MusicSearchService {
    suspend fun fetchHomeFeedTracks(): SearchResponse
    suspend fun searchTracks(query: String): SearchResponse
}

class OnlineMusicSearchService : MusicSearchService {

    @Volatile
    private var cachedHosts: List<String> = emptyList()

    @Volatile
    private var hostsFetchedAtMs: Long = 0L

    override suspend fun fetchHomeFeedTracks(): SearchResponse = withContext(Dispatchers.IO) {
        val audiusTracks = fetchAudiusTrending()
        if (audiusTracks.isNotEmpty()) {
            return@withContext SearchResponse(
                tracks = audiusTracks,
                source = TrackSource.AUDIUS,
                isFallbackUsed = false
            )
        }

        val itunesFallback = searchItunes("top hits bollywood chill")
        if (itunesFallback.isNotEmpty()) {
            return@withContext SearchResponse(
                tracks = itunesFallback,
                source = TrackSource.ITUNES,
                isFallbackUsed = true
            )
        }

        SearchResponse(
            tracks = emptyList(),
            source = TrackSource.AUDIUS,
            isFallbackUsed = true,
            errorMessage = "Unable to load online tracks right now. Check your internet connection."
        )
    }

    override suspend fun searchTracks(query: String): SearchResponse = withContext(Dispatchers.IO) {
        val clean = query.trim()
        if (clean.length < 2) {
            return@withContext fetchHomeFeedTracks()
        }

        val audiusTracks = searchAudius(clean)
        if (audiusTracks.isNotEmpty()) {
            return@withContext SearchResponse(
                tracks = audiusTracks,
                source = TrackSource.AUDIUS,
                isFallbackUsed = false
            )
        }

        val itunesTracks = searchItunes(clean)
        if (itunesTracks.isNotEmpty()) {
            return@withContext SearchResponse(
                tracks = itunesTracks,
                source = TrackSource.ITUNES,
                isFallbackUsed = true
            )
        }

        SearchResponse(
            tracks = emptyList(),
            source = TrackSource.ITUNES,
            isFallbackUsed = true,
            errorMessage = "No matching tracks found for \"$clean\""
        )
    }

    private fun resolveAudiusHosts(): List<String> {
        val now = System.currentTimeMillis()
        if (cachedHosts.isNotEmpty() && now - hostsFetchedAtMs < HOST_CACHE_TTL_MS) {
            return cachedHosts
        }

        val discovered = runCatching {
            val body = httpGet("https://api.audius.co", timeoutMs = 4500) ?: return@runCatching emptyList()
            val arr = JSONObject(body).optJSONArray("data") ?: return@runCatching emptyList()
            buildList {
                for (i in 0 until arr.length()) {
                    val host = arr.optString(i).trim().trimEnd('/')
                    if (host.startsWith("https://") || host.startsWith("http://")) {
                        add(host)
                    }
                }
            }
        }.getOrDefault(emptyList())

        val combined = (discovered + FALLBACK_AUDIUS_HOSTS).distinct().take(4)
        if (discovered.isNotEmpty()) {
            cachedHosts = combined
            hostsFetchedAtMs = now
        }
        return combined
    }

    private fun fetchAudiusTrending(): List<MusicTrack> {
        val hosts = resolveAudiusHosts()
        for (host in hosts) {
            val tracks = runCatching {
                val url = "$host/v1/tracks/trending?app_name=MOHITMusic&limit=20"
                val body = httpGet(url, timeoutMs = 5500) ?: return@runCatching emptyList()
                parseAudiusTracks(body, host)
            }.getOrDefault(emptyList())
            if (tracks.isNotEmpty()) return tracks
        }
        return emptyList()
    }

    private fun searchAudius(query: String): List<MusicTrack> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val hosts = resolveAudiusHosts()
        for (host in hosts) {
            val tracks = runCatching {
                val url = "$host/v1/tracks/search?query=$encoded&app_name=MOHITMusic&limit=25"
                val body = httpGet(url, timeoutMs = 5500) ?: return@runCatching emptyList()
                parseAudiusTracks(body, host)
            }.getOrDefault(emptyList())
            if (tracks.isNotEmpty()) return tracks
        }
        return emptyList()
    }

    private fun parseAudiusTracks(body: String, host: String): List<MusicTrack> {
        val json = JSONObject(body)
        val data = json.optJSONArray("data") ?: return emptyList()
        val list = mutableListOf<MusicTrack>()
        val artKeys = listOf("gradient_cyan", "gradient_indigo", "gradient_sunset", "gradient_emerald")

        for (i in 0 until data.length()) {
            val obj = data.optJSONObject(i) ?: continue
            val isStreamable = obj.optBoolean("is_streamable", true)
            if (!isStreamable) continue

            val id = obj.optString("id").trim()
            val title = obj.optString("title").trim()
            if (id.isBlank() || title.isBlank()) continue

            val userObj = obj.optJSONObject("user")
            val artist = userObj?.optString("name")?.trim()?.ifBlank {
                userObj.optString("handle").trim()
            }?.ifBlank { "Audius Artist" } ?: "Audius Artist"

            val artworkObj = obj.optJSONObject("artwork")
            val artworkUrl = listOf("480x480", "150x150", "1000x1000")
                .firstNotNullOfOrNull { key ->
                    artworkObj?.optString(key)?.trim()?.takeIf { it.startsWith("http") }
                } ?: ""

            val durationSec = obj.optInt("duration", 180).coerceAtLeast(1)
            val streamUrl = "$host/v1/tracks/$id/stream?app_name=MOHITMusic"

            list.add(
                MusicTrack(
                    id = "audius_$id",
                    title = title,
                    artist = artist,
                    album = obj.optString("genre").trim(),
                    artworkUrl = artworkUrl,
                    streamUrl = streamUrl,
                    durationSeconds = durationSec,
                    source = TrackSource.AUDIUS,
                    artworkKey = artKeys[i % artKeys.size]
                )
            )
        }
        return list
    }

    private fun searchItunes(query: String): List<MusicTrack> {
        return runCatching {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = "https://itunes.apple.com/search?term=$encoded&media=music&entity=song&limit=25"
            val body = httpGet(url, timeoutMs = 5500) ?: return@runCatching emptyList()
            val results = JSONObject(body).optJSONArray("results") ?: return@runCatching emptyList()
            val list = mutableListOf<MusicTrack>()
            val artKeys = listOf("gradient_cyan", "gradient_indigo", "gradient_sunset", "gradient_emerald")

            for (i in 0 until results.length()) {
                val obj = results.optJSONObject(i) ?: continue
                val trackName = obj.optString("trackName").trim()
                val previewUrl = obj.optString("previewUrl").trim()
                if (trackName.isBlank() || previewUrl.isBlank()) continue

                val artistName = obj.optString("artistName").trim().ifBlank { "iTunes Artist" }
                val albumName = obj.optString("collectionName").trim()
                val artworkUrl = obj.optString("artworkUrl100").trim()
                    .replace("100x100bb", "400x400bb")
                val trackId = obj.optLong("trackId", (1_000_000L + i))
                val durationSec = ((obj.optLong("trackTimeMillis", 30_000L) / 1000L)
                    .coerceIn(25L, 600L)).toInt()

                list.add(
                    MusicTrack(
                        id = "itunes_$trackId",
                        title = trackName,
                        artist = artistName,
                        album = albumName,
                        artworkUrl = artworkUrl,
                        streamUrl = previewUrl,
                        durationSeconds = durationSec,
                        source = TrackSource.ITUNES,
                        artworkKey = artKeys[i % artKeys.size]
                    )
                )
            }
            list
        }.getOrDefault(emptyList())
    }

    private fun httpGet(urlString: String, timeoutMs: Int): String? {
        val url = URL(urlString)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = timeoutMs
            readTimeout = timeoutMs
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "MOHITMusicAndroid/1.0")
        }
        return try {
            if (conn.responseCode !in 200..299) {
                null
            } else {
                conn.inputStream.bufferedReader().use { it.readText() }
            }
        } finally {
            conn.disconnect()
        }
    }

    private companion object {
        const val HOST_CACHE_TTL_MS = 10 * 60 * 1000L
        val FALLBACK_AUDIUS_HOSTS = listOf(
            "https://discoveryprovider.audius.co",
            "https://discoveryprovider2.audius.co",
            "https://discoveryprovider3.audius.co"
        )
    }
}
