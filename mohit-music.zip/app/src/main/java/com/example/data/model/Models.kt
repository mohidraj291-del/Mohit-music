package com.example.data.model

enum class TrackSource(val label: String) {
    AUDIUS("Audius"),
    ITUNES("iTunes")
}

data class MusicTrack(
    val id: String,
    val title: String,
    val artist: String,
    val album: String = "",
    val artworkUrl: String = "",
    val streamUrl: String = "",
    val durationSeconds: Int = 0,
    val source: TrackSource = TrackSource.AUDIUS,
    val artworkKey: String = "gradient_cyan"
)

data class AppConfig(
    val appEnabled: Boolean = true,
    val maintenanceMessage: String = "",
    val noticeText: String = ""
)

data class UserRtdbProfile(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val photoURL: String = "",
    val isPremium: Boolean = false,
    val online: Boolean = false,
    val lastSeen: Long = 0L,
    val deviceInfo: String = ""
)

data class AuthenticatedUserInfo(
    val uid: String,
    val name: String,
    val email: String,
    val photoUrl: String
)

data class SearchResponse(
    val tracks: List<MusicTrack>,
    val source: TrackSource,
    val isFallbackUsed: Boolean = false,
    val errorMessage: String? = null
)

enum class AudioEqPreset(
    val label: String,
    val description: String,
    val requiresPremium: Boolean
) {
    STANDARD("Standard", "Balanced studio output", false),
    DEEP_BASS("Cyan Sub-Bass", "Enhanced low-end punch", true),
    STUDIO_CRISP("Studio Crisp", "Vocal & high-hat clarity", true),
    SPATIAL_HALL("Spatial Stage", "Wide atmospheric soundstage", true)
}
