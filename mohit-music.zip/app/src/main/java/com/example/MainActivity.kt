package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.automirrored.outlined.QueueMusic
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.auth.authStateFlow
import com.example.data.auth.signOut
import com.example.data.auth.toAuthenticatedUserInfo
import com.example.data.model.AuthenticatedUserInfo
import com.example.data.remote.OnlineMusicSearchService
import com.example.data.repository.FirebaseRealtimeDatabaseRepository
import com.example.ui.components.MiniPlayerBar
import com.example.ui.components.NowPlayingOverlay
import com.example.ui.components.TopHeaderBar
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MaintenanceScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.QueueScreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.MohitMusicTheme
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

private enum class MohitNavTab(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    Home("home", "Home", Icons.Filled.Home, Icons.Outlined.Home),
    Queue("queue", "Queue", Icons.AutoMirrored.Filled.QueueMusic, Icons.AutoMirrored.Outlined.QueueMusic),
    Profile("profile", "Profile", Icons.Filled.Person, Icons.Outlined.Person)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.BLACK),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.BLACK)
        )
        setContent {
            MohitMusicTheme {
                AppNavigation()
            }
        }
    }
}

@Composable
fun AppNavigation(
    auth: FirebaseAuth = Firebase.auth
) {
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val firebaseUser = currentUser

    if (firebaseUser == null) {
        AuthScreen(onAuthSuccess = {})
    } else {
        val authInfo = remember(firebaseUser.uid, firebaseUser.displayName, firebaseUser.email, firebaseUser.photoUrl) {
            firebaseUser.toAuthenticatedUserInfo()
        }
        key(firebaseUser.uid) {
            MohitMusicAuthenticatedShell(user = authInfo)
        }
    }
}

@Composable
private fun MohitMusicAuthenticatedShell(
    user: AuthenticatedUserInfo
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val viewModel: MainViewModel = viewModel(
        key = user.uid,
        factory = viewModelFactory {
            initializer {
                MainViewModel(
                    currentUser = user,
                    cloudRepository = FirebaseRealtimeDatabaseRepository(),
                    searchService = OnlineMusicSearchService()
                )
            }
        }
    )

    val handleSignOut: () -> Unit = {
        signOut(
            credentialManager = credentialManager,
            scope = scope,
            onBeforeFirebaseSignOut = { viewModel.prepareForSignOut() }
        )
    }

    MohitMusicAppContent(
        viewModel = viewModel,
        onSignOut = handleSignOut
    )
}

@Composable
fun MohitMusicAppContent(
    viewModel: MainViewModel,
    onSignOut: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var showNowPlaying by remember { mutableStateOf(false) }

    if (!uiState.appConfig.appEnabled) {
        showNowPlaying = false
        MaintenanceScreen(
            appConfig = uiState.appConfig,
            user = uiState.user,
            onSignOut = onSignOut
        )
        return
    }

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: MohitNavTab.Home.route

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.statusToast) {
        val msg = uiState.statusToast
        if (msg != null) {
            snackbarHostState.currentSnackbarData?.dismiss()
            viewModel.clearStatusToast()
            snackbarHostState.showSnackbar(msg)
        }
    }

    val navigateToTab: (String) -> Unit = { route ->
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(PitchBlack)
    ) {
        val useNavigationRail = maxWidth >= 600.dp

        Row(modifier = Modifier.fillMaxSize()) {
            if (useNavigationRail) {
                NavigationRail(
                    containerColor = SurfaceDark,
                    contentColor = TextPrimary,
                    modifier = Modifier
                        .fillMaxHeight()
                        .statusBarsPadding()
                        .testTag("navigation_rail")
                ) {
                    MohitNavTab.entries.forEach { tab ->
                        val selected = currentRoute == tab.route
                        NavigationRailItem(
                            selected = selected,
                            onClick = { navigateToTab(tab.route) },
                            icon = {
                                Icon(
                                    imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = tab.label
                                )
                            },
                            label = { Text(tab.label) },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = CyanAccent,
                                selectedTextColor = CyanAccent,
                                indicatorColor = SurfaceElevated,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            ),
                            modifier = Modifier.testTag("nav_rail_${tab.route}")
                        )
                    }
                }
            }

            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                Scaffold(
                    containerColor = PitchBlack,
                    contentColor = TextPrimary,
                    contentWindowInsets = WindowInsets(0, 0, 0, 0),
                    topBar = {
                        TopHeaderBar(
                            user = uiState.user,
                            isPremium = uiState.isPremium,
                            isOnline = uiState.isOnline,
                            onAvatarClick = { navigateToTab(MohitNavTab.Profile.route) },
                            modifier = Modifier.statusBarsPadding()
                        )
                    },
                    bottomBar = {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(PitchBlack)
                        ) {
                            MiniPlayerBar(
                                playback = uiState.playback,
                                onExpand = { showNowPlaying = true },
                                onTogglePlayPause = { viewModel.togglePlayPause() },
                                onSkipNext = { viewModel.skipNext() }
                            )

                            if (!useNavigationRail) {
                                NavigationBar(
                                    containerColor = SurfaceDark,
                                    contentColor = TextPrimary,
                                    tonalElevation = 0.dp,
                                    windowInsets = WindowInsets.navigationBars,
                                    modifier = Modifier.testTag("bottom_navigation_bar")
                                ) {
                                    MohitNavTab.entries.forEach { tab ->
                                        val selected = currentRoute == tab.route
                                        NavigationBarItem(
                                            selected = selected,
                                            onClick = { navigateToTab(tab.route) },
                                            icon = {
                                                Icon(
                                                    imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                                    contentDescription = tab.label
                                                )
                                            },
                                            label = { Text(tab.label) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = CyanAccent,
                                                selectedTextColor = CyanAccent,
                                                indicatorColor = SurfaceElevated,
                                                unselectedIconColor = TextSecondary,
                                                unselectedTextColor = TextSecondary
                                            ),
                                            modifier = Modifier.testTag("nav_tab_${tab.route}")
                                        )
                                    }
                                }
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        contentAlignment = Alignment.TopCenter,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        NavHost(
                            navController = navController,
                            startDestination = MohitNavTab.Home.route,
                            modifier = Modifier
                                .fillMaxSize()
                                .widthIn(max = 920.dp)
                        ) {
                            composable(MohitNavTab.Home.route) {
                                HomeScreen(
                                    uiState = uiState,
                                    onSearchQueryChange = { viewModel.onSearchQueryChanged(it) },
                                    onImmediateSearch = { viewModel.triggerImmediateSearch(it) },
                                    onRetryHomeFeed = { viewModel.loadHomeFeed() },
                                    onPlayTrack = { track, list -> viewModel.playTrack(track, list) },
                                    onTogglePlayPause = { viewModel.togglePlayPause() },
                                    onAddToQueue = { viewModel.addToQueue(it) }
                                )
                            }
                            composable(MohitNavTab.Queue.route) {
                                QueueScreen(
                                    playback = uiState.playback,
                                    isPremium = uiState.isPremium,
                                    onPlayTrack = { track, list -> viewModel.playTrack(track, list) },
                                    onTogglePlayPause = { viewModel.togglePlayPause() },
                                    onRemoveFromQueue = { viewModel.removeFromQueue(it) },
                                    onClearUpcoming = { viewModel.clearUpcomingQueue() },
                                    onSelectEqPreset = { viewModel.selectEqPreset(it) }
                                )
                            }
                            composable(MohitNavTab.Profile.route) {
                                ProfileScreen(
                                    uiState = uiState,
                                    onSignOut = onSignOut
                                )
                            }
                        }
                    }
                }

                NowPlayingOverlay(
                    visible = showNowPlaying,
                    playback = uiState.playback,
                    isPremium = uiState.isPremium,
                    onDismiss = { showNowPlaying = false },
                    onTogglePlayPause = { viewModel.togglePlayPause() },
                    onSkipNext = { viewModel.skipNext() },
                    onSkipPrevious = { viewModel.skipPrevious() },
                    onSeek = { viewModel.seekTo(it) },
                    onToggleShuffle = { viewModel.toggleShuffle() },
                    onToggleRepeat = { viewModel.toggleRepeat() },
                    onOpenQueueTab = { navigateToTab(MohitNavTab.Queue.route) }
                )

                SnackbarHost(
                    hostState = snackbarHostState,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .statusBarsPadding()
                        .padding(top = 6.dp)
                )
            }
        }
    }
}
