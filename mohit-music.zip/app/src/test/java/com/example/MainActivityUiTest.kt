package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import com.example.data.model.AppConfig
import com.example.data.model.AuthenticatedUserInfo
import com.example.ui.screens.AuthScreen
import com.example.ui.theme.MohitMusicTheme
import com.example.ui.viewmodel.MainViewModel
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w411dp-h915dp-xxhdpi")
class MainActivityUiTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun authScreen_rendersGoogleSignInButton_withoutAnyPhoneField() {
        composeRule.setContent {
            MohitMusicTheme {
                AuthScreen(onAuthSuccess = {})
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("auth_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("google_sign_in_button").assertIsDisplayed()
        assert(composeRule.onAllNodesWithText("Phone", substring = true, ignoreCase = true).fetchSemanticsNodes().isEmpty())
    }

    @Test
    fun liveSearch_miniPlayer_premiumBadge_andMaintenanceBlocker_workInRealTime() {
        val fakeRepo = FakeCloudRepository()
        val fakeSearch = FakeSearchService()
        val user = AuthenticatedUserInfo("uid_mohit_1", "Mohit Raj", "mohit@gmail.com", "")
        val vm = MainViewModel(
            currentUser = user,
            cloudRepository = fakeRepo,
            searchService = fakeSearch,
            debounceMillis = 50L,
            enableAudioEngine = false
        )

        composeRule.setContent {
            MohitMusicTheme {
                MohitMusicAppContent(
                    viewModel = vm,
                    onSignOut = {}
                )
            }
        }

        // Initial Home feed + FREE badge
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("home_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("header_plan_badge").assertIsDisplayed()
        composeRule.onNodeWithText("FREE").assertIsDisplayed()
        composeRule.onNodeWithText("Kesariya Cyan").assertIsDisplayed()

        // Search input triggers live search and track click opens persistent mini-player
        composeRule.onNodeWithTag("home_search_input").performTextInput("Arijit")
        composeRule.waitUntil(timeoutMillis = 3000) {
            composeRule.onAllNodes(androidx.compose.ui.test.hasTestTag("track_card_audius_101"))
                .fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("track_card_audius_101").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("mini_player_bar").assertIsDisplayed()

        // Expand full player
        composeRule.onNodeWithTag("mini_player_bar").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("now_playing_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("now_playing_close_button").performClick()
        composeRule.waitForIdle()

        // Live Premium flip updates header badge to PREMIUM immediately
        fakeRepo.profileFlow.value = fakeRepo.profileFlow.value.copy(isPremium = true)
        composeRule.waitUntil(timeoutMillis = 3000) {
            composeRule.onAllNodesWithText("PREMIUM").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithText("PREMIUM").assertIsDisplayed()

        // Live Maintenance flip blocks main app and shows maintenanceMessage + noticeText
        fakeRepo.configFlow.value = AppConfig(
            appEnabled = false,
            maintenanceMessage = "Scheduled Upgrade Underway",
            noticeText = "Audio returns shortly"
        )
        composeRule.waitUntil(timeoutMillis = 3000) {
            composeRule.onAllNodesWithText("Scheduled Upgrade Underway").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("maintenance_screen").assertIsDisplayed()
        composeRule.onNodeWithText("Audio returns shortly").assertIsDisplayed()
    }
}
