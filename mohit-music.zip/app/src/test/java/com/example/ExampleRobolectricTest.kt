package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AppConfig
import com.example.data.model.AudioEqPreset
import com.example.data.model.AuthenticatedUserInfo
import com.example.data.model.MusicTrack
import com.example.data.model.SearchResponse
import com.example.data.model.TrackSource
import com.example.data.model.UserRtdbProfile
import com.example.data.remote.MusicSearchService
import com.example.data.repository.MusicCloudRepository
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `app_name matches MOHIT Music`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("MOHIT Music", context.getString(R.string.app_name))
    }

    @Test
    fun `sign-in syncs profile, registers disconnect, and live appConfig and isPremium control state`() = runTest(testDispatcher) {
        val fakeRepo = FakeCloudRepository()
        val fakeSearch = FakeSearchService()
        val user = AuthenticatedUserInfo(
            uid = "uid_mohit_1",
            name = "Mohit Raj",
            email = "mohit@gmail.com",
            photoUrl = "https://example.com/photo.png"
        )

        val vm = MainViewModel(
            currentUser = user,
            cloudRepository = fakeRepo,
            searchService = fakeSearch,
            debounceMillis = 400L,
            enableAudioEngine = false
        )
        advanceUntilIdle()

        assertEquals(user, fakeRepo.lastSyncedUser)
        assertTrue(fakeRepo.disconnectAttached)
        assertFalse(vm.uiState.value.isPremium)
        assertTrue(vm.uiState.value.appConfig.appEnabled)

        // Play track works while appEnabled == true
        val track = fakeSearch.sampleTracks.first()
        vm.playTrack(track, fakeSearch.sampleTracks)
        assertTrue(vm.uiState.value.playback.isPlaying)

        // Flip isPremium = true -> unlocks premium immediately
        fakeRepo.profileFlow.value = fakeRepo.profileFlow.value.copy(isPremium = true, online = true)
        advanceUntilIdle()
        assertTrue(vm.uiState.value.isPremium)
        vm.selectEqPreset(AudioEqPreset.DEEP_BASS)
        assertEquals(AudioEqPreset.DEEP_BASS, vm.uiState.value.playback.activeEqPreset)

        // Flip appEnabled = false -> pauses playback and exposes maintenance screen config
        fakeRepo.configFlow.value = AppConfig(
            appEnabled = false,
            maintenanceMessage = "Server upgrade in progress",
            noticeText = "Back in 15 minutes"
        )
        advanceUntilIdle()
        assertFalse(vm.uiState.value.appConfig.appEnabled)
        assertEquals("Server upgrade in progress", vm.uiState.value.appConfig.maintenanceMessage)
        assertEquals("Back in 15 minutes", vm.uiState.value.appConfig.noticeText)
        assertFalse(vm.uiState.value.playback.isPlaying)
    }

    @Test
    fun `debounced search waits 400ms before calling Audius and iTunes service`() = runTest(testDispatcher) {
        val fakeRepo = FakeCloudRepository()
        val fakeSearch = FakeSearchService()
        val user = AuthenticatedUserInfo("u1", "Mohit", "mohit@gmail.com", "")

        val vm = MainViewModel(
            currentUser = user,
            cloudRepository = fakeRepo,
            searchService = fakeSearch,
            debounceMillis = 400L,
            enableAudioEngine = false
        )
        advanceUntilIdle()

        vm.onSearchQueryChanged("ar")
        advanceTimeBy(200L)
        assertEquals(0, fakeSearch.searchCalls.size)

        vm.onSearchQueryChanged("arijit")
        advanceTimeBy(399L)
        assertEquals(0, fakeSearch.searchCalls.size)

        advanceTimeBy(2L)
        advanceUntilIdle()
        assertEquals(listOf("arijit"), fakeSearch.searchCalls)
        assertEquals("Kesariya Cyan", vm.uiState.value.searchResults.first().title)
    }
}

class FakeCloudRepository : MusicCloudRepository {
    override val isDatabaseConfigured: Boolean = true
    override val databaseStatusLabel: String = "https://mock-rtdb.firebaseio.com"

    var lastSyncedUser: AuthenticatedUserInfo? = null
    var disconnectAttached: Boolean = false
    var markedOfflineUid: String? = null

    val configFlow = MutableStateFlow(AppConfig(appEnabled = true, maintenanceMessage = "", noticeText = ""))
    val profileFlow = MutableStateFlow(
        UserRtdbProfile(
            uid = "uid_mohit_1",
            name = "Mohit Raj",
            email = "mohit@gmail.com",
            photoURL = "",
            isPremium = false,
            online = true,
            deviceInfo = "Pixel 9"
        )
    )

    override suspend fun syncUserProfileAndPresence(user: AuthenticatedUserInfo, deviceInfo: String) {
        lastSyncedUser = user
        profileFlow.value = profileFlow.value.copy(
            uid = user.uid,
            name = user.name,
            email = user.email,
            photoURL = user.photoUrl,
            deviceInfo = deviceInfo,
            online = true
        )
    }

    override fun attachPresenceDisconnectHandler(uid: String): () -> Unit {
        disconnectAttached = true
        return { }
    }

    override suspend fun markOffline(uid: String) {
        markedOfflineUid = uid
        profileFlow.value = profileFlow.value.copy(online = false)
    }

    override fun observeAppConfig(): Flow<AppConfig> = configFlow

    override fun observeUserProfile(uid: String): Flow<UserRtdbProfile> = profileFlow
}

class FakeSearchService : MusicSearchService {
    val searchCalls = mutableListOf<String>()
    val sampleTracks = listOf(
        MusicTrack(
            id = "audius_101",
            title = "Kesariya Cyan",
            artist = "Arijit Singh",
            streamUrl = "https://example.com/101.mp3",
            durationSeconds = 215,
            source = TrackSource.AUDIUS
        ),
        MusicTrack(
            id = "itunes_202",
            title = "Midnight Lo-Fi",
            artist = "Mohit Beats",
            streamUrl = "https://example.com/202.mp3",
            durationSeconds = 30,
            source = TrackSource.ITUNES
        )
    )

    override suspend fun fetchHomeFeedTracks(): SearchResponse {
        return SearchResponse(tracks = sampleTracks, source = TrackSource.AUDIUS)
    }

    override suspend fun searchTracks(query: String): SearchResponse {
        searchCalls.add(query)
        delay(10L)
        return SearchResponse(
            tracks = sampleTracks.filter {
                it.title.contains(query, ignoreCase = true) ||
                    it.artist.contains(query, ignoreCase = true)
            }.ifEmpty { listOf(sampleTracks.last()) },
            source = TrackSource.AUDIUS
        )
    }
}
